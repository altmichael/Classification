function labelNum = labelCheckergender(str)

    if strcmp(str,'m')
        labelNum=1;
    end
    if strcmp(str,'f')
        labelNum=2;
    end

end